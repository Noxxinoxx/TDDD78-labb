I den här katalogen kan man lägga *resursfiler* -- bilder, ljudfiler och andra filer som programmet ska kunna komma åt när det körs. Alla
filer som ligger under "resources", även i underkataloger, kopieras in i det färdiga *programmet* när det kompileras.

Du kan se exempel på detta i klassen `Test`.

Det går också bra att skapa nya kataloger under "resources" om programmet vill läsa medskickade filer som inte är bilder eller ljudfiler.
