Detta bibliotek innehåller ett par experimentella annoteringar (annotations) som kan komma att användas i TDDD78 / TDDE30 under

2023.

Om vi använder dessa kommer de att dokumenteras i instruktionerna.
