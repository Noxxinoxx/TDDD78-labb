package se.liu.noaan869.LabbTetris;


public interface CollisionHandler {
    public boolean hasCollision(Board board);
    //get description.
    public String getDescription();

}