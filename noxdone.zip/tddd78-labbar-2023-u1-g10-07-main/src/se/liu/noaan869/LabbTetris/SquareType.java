package se.liu.noaan869.LabbTetris;


public enum SquareType {
	EMPTY, I, O, T, S, Z, J, L, OUTSIDE
}

