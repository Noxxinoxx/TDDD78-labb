package se.liu.noaan869.LabbTetris;


public class TestBoard {
	public static void main(String[] args) {
		//Test class also used to run the program at this point. implement main game loop class soon.

		new Board(15, 20);

	}
	
}
