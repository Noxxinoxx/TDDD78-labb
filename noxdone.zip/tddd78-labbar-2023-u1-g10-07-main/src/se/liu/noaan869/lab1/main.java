package se.liu.noaan869.lab1;

public class main {
	
	public static void main(String[] args) {
		System.out.println("Hello world!");
	}
	
	
}
