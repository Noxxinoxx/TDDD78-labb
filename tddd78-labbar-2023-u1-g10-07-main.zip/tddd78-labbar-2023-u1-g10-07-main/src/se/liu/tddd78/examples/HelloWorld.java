package se.liu.tddd78.examples;

/**
 * A simple test class used to verify that your development environment is working.
 */
public class HelloWorld
{
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
