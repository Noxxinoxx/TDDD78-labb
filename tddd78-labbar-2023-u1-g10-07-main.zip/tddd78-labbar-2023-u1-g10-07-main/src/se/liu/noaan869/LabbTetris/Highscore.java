package se.liu.noaan869.LabbTetris;

public class Highscore {
	private final String name;
    private final String score;

    public Highscore(String name, String score){
		this.name = name;
		this.score = score;
    }

    public int getScore(){
    	return Integer.parseInt(score);
    }
    
    public String getName(){
    	return name;
    }

    
}
