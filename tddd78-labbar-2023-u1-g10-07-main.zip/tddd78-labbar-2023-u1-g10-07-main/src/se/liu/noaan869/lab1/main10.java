package se.liu.noaan869.lab1;

public class main10 {
	public static void main(String[] args) {
		
		int number = 16777216;
		float decimal = number; 
		int integerAgain = (int) decimal;
		System.out.println(number);
		System.out.println(decimal);
		System.out.println(integerAgain);
		
		int  big = 2147483647;
		long  bigger = (long)big+1;
		System.out.println(big);
		System.out.println(bigger);		
	}
	
}
