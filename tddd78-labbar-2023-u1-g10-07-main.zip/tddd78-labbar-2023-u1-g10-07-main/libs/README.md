Under *libs* kan man skapa egna kataloger för klassbibliotek som man vill använda. Det gäller främst under projektdelen av kursen.

Man kan markera en eller flera JAR-filer som man har placerat i en katalog (klick och ctrl-click), högerklicka, och välja "Add as library".
Då adderas filerna som ett
"library" i IDEA och klasserna blir tillgängliga för programmering och exekvering.

Se https://www.jetbrains.com/help/idea/library.html för mer info om libraries i IDEA.
